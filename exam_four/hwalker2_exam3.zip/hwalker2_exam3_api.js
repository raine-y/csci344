/*

What is a webAPI?

A Web API is an interface where a developer can access a set of rules and protocols 
that allows different software applications to communicate with each other over 
the internet. It takes requests and gives responses concerning the exchange of WHAT data HOW
to the client.

Three common examples of WebAPIs are:

1. DOM (Document Object Model) API
2. Fetch API
3. Geolocation API

Below is an example program demonstrating how to manipulate a hypothetical html file with the DOM api

*/

function changeText() {
    let targetElement = document.getElementById("myText");

    targetElement.textContent = "This text has been changed by the DOM API!";

    targetElement.style.color = "green";
    targetElement.style.fontWeight = "bolder";
}